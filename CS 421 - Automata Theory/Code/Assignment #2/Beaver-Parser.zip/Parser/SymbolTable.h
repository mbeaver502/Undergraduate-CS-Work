/*
Michael Beaver
CS 421 - Automata Theory & Compiler Construction
Assignment #2 - MINI-P Parser
27 April 2015
Program Description:
	This program implements a parser for a MINI-P compiler. This program emulates
	the basic function of a parser as it would continuously prompt the Scanner to
	scan tokens in the buffer. Special note: This implementation assumes all
	executable statements (i.e., assign, read, write) end with a semicolon. This
	implementation also will stop trying to parse if it encounters a bad statement.
	Any statements after the initial bad statement will not be parsed (correctly),
	but the bad statement will be identified. In this case, the parser will also
	attempt to parse the END. keyword, which will obviously fail.
*/

#ifndef SYMBOLTABLE_H
#define SYMBOLTABLE_H

#include "Constants.h"

//--------------------------------------------------------------------------

class SymbolTable {

	private:

		int originalNumKeys;
		int tableSize;
		Record * table;
		bool slotsOpen;
		Record initVal;

		bool isPrime(const int val) const;
		int NewSlot(const unsigned int HashVal, int & tryNumber) const;
		bool querySlotsOpen() const;
		unsigned int doHash(const char name[]) const;


	public:

		SymbolTable();
		SymbolTable(const int numKeys);
		SymbolTable(const SymbolTable & source);
		~SymbolTable();

		SymbolTable& operator =(const SymbolTable & source);
		char * operator [](const int key) const;

		int areOpenSlots();
		int Insert(const Record key);
		bool Remove(const char name[]);
		int Search(const char name[]) const;
		void ClearTable();

		int getOriginalNumKeys() const;
		int getTableSize() const;
		int getRecordCode(const char name[]) const;
		bool setRecordCode(const char name[], const int code);

};

#endif
