﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MemoryTest;

namespace MemoryTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter memory size in bytes: ");
            string size = Console.ReadLine();
            Memory systemMem = new Memory(Convert.ToInt32(size));

            int sz = systemMem.GetMemorySize();
            Console.WriteLine(systemMem.GetBytesString(0, sz - 1));

            //---------------------------------------------------------------

            Register myReg = new Register();
            byte[] x = myReg.GetBytes(0, 3);

            myReg.SetByte(4, "C3");
            Console.WriteLine(myReg.GetBytesString(0, 3));

            //--------------------------------------------------------------

            PSW myPSW = new PSW();

            string[] z = { "00", "01", "A2" };
            myPSW.SetBytes(0, z);

            myPSW.SetCondCode(1, 0);

            Console.WriteLine(myPSW.GetBytesString(0, 2));
            Console.WriteLine(myPSW.GetCondCodeInt());

            Console.ReadLine();
        }
    }
}
