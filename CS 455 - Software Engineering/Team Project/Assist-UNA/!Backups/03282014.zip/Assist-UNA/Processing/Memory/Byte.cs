﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bit;

/**************************************************************************************************
* 
* Name: AssistByte
* 
* ================================================================================================
* 
* Description: !!!!!!!!!!!!!!!!!!!!
* 
*              
*                       
* ================================================================================================        
* 
* Modification History
* --------------------
* 03/25/2014    JMB  Class created.
*                      
*************************************************************************************************/

class AssistByte
{
    
    /* Constants. */
    const int DEFAULT_F4_INT_VALUE = 244;
    const int DEFAULT_F5_INT_VALUE = 245;
    const int NIBBLE_SIZE = 4;
    const string DEFAULT_F4_HEX_VALUE = "F4";
    const string DEFAULT_F4_HIGH_NIBBLE = "1111";
    const string DEFAULT_F4_LOW_NIBBLE = "0100";
    const string DEFAULT_F5_HEX_VALUE = "F5";
    const string DEFAULT_F5_HIGH_NIBBLE = "1111";
    const string DEFAULT_F5_LOW_NIBBLE = "0101";

    /* Private members. */
    Bit[] high = new Bit[NIBBLE_SIZE];
    Bit[] low = new Bit[NIBBLE_SIZE];
    bool locked;
    int value;
    string hexValue;


    /* Public methods. */

    /******************************************************************************************
     * 
     * Name: AssistByte   
     * 
     * Author(s): Michael Beaver
     *                 
     * Input: !!!!!!!!!!!!!!!!!!!!
     * Return: !!!!!!!!!!!!!!!!!!!!
     * Description: !!!!!!!!!!!!!!!!!!!!
     *
     *****************************************************************************************/
    public AssistByte()
    {
        /* Set the F5 bits. */
        for (int i = 0; i < NIBBLE_SIZE; i++)
        {
            high[i] = Convert.ToInt32(DEFAULT_F5_HIGH_NIBBLE[i]);
            low[i] = Convert.ToInt32(DEFAULT_F5_LOW_NIBBLE[i]);
        }

        locked = false;
        value = DEFAULT_F5_INT_VALUE;
        hexValue = DEFAULT_F5_HEX_VALUE;
    }

    /******************************************************************************************
     * 
     * Name: GetBothNibbles   
     * 
     * Author(s): Michael Beaver
     *                 
     * Input: !!!!!!!!!!!!!!!!!!!!
     * Return: N/A
     * Description: Returns both nibble arrays via arrays passed as arguments.
     *
     *****************************************************************************************/
    public void GetBothNibbles(Bit[] highDest, Bit[] lowDest)
    {
        for (int i = 0; i < NIBBLE_SIZE; i++)
        {
            highDest[i] = high[i];
            lowDest[i] = low[i];
        }
    }

    /******************************************************************************************
     * 
     * Name: GetHexValue   
     * 
     * Author(s): Michael Beaver
     *                 
     * Input: N/A
     * Return: String
     * Description: Returns the hexadecimal value of the Byte.
     *
     *****************************************************************************************/
    public string GetHexValue()
    {
        return hexValue;
    }

    /******************************************************************************************
     * 
     * Name: GetHighNibble   
     * 
     * Author(s): Michael Beaver
     *                 
     * Input: !!!!!!!!!!!!!!!!!!!!
     * Return: N/A
     * Description: Returns the high nibble array via an array passed as an argument.
     *
     *****************************************************************************************/
    public void GetHighNibble(Bit[] highDest)
    {
        for (int i = 0; i < NIBBLE_SIZE; i++)
            highDest[i] = high[i];
    }

    /******************************************************************************************
     * 
     * Name: GetIntegerValue   
     * 
     * Author(s): Michael Beaver
     *                 
     * Input: N/A
     * Return: Integer
     * Description: !!!!!!!!!!!!!!!!!!!!
     *
     *****************************************************************************************/
    public int GetIntegerValue()
    {
        return value;
    }

    /******************************************************************************************
     * 
     * Name: GetLowNibble   
     * 
     * Author(s): Michael Beaver
     *                 
     * Input: !!!!!!!!!!!!!!!!!!!!
     * Return: N/A
     * Description: Returns the low nibble array via an array passed as an argument.
     *
     *****************************************************************************************/
    public void GetLowNibble(Bit[] lowDest)
    {
        for (int i = 0; i < NIBBLE_SIZE; i++)
            lowDest[i] = low[i];
    }

    /******************************************************************************************
     * 
     * Name: IsLocked       
     * 
     * Author(s): Michael Beaver
     *                           
     * Input: N/A
     * Return: True/False  
     * Description: This method returns true if the Byte is locked from modification  
     *              (i.e., constant). This method returns false if the Byte is not locked.
     *              
     *****************************************************************************************/
    public bool IsLocked()
    {
        return locked;
    }

    /******************************************************************************************
     * 
     * Name: SetBothNibbles   
     * 
     * Author(s): Michael Beaver
     *                 
     * Input: !!!!!!!!!!!!!!!!!!!!
     * Return: True/False
     * Description: !!!!!!!!!!!!!!!!!!!!
     *
     *****************************************************************************************/
    public bool SetBothNibbles(Bit[] highSrc, Bit[] lowSrc)
    {        
        /* Attempt to set the high nibble. */
        if (!(SetHighNibble(highSrc[NIBBLE_SIZE])))
            return false;

        /* Attempt to set the low nibble. */
        if (!(SetLowNibble(lowSrc[NIBBLE_SIZE])))
            return false;

        return true;
    }

    /******************************************************************************************
     * 
     * Name: SetHexValue   
     * 
     * Author(s): Michael Beaver
     *                 
     * Input: !!!!!!!!!!!!!!!!!!!!
     * Return: True/False
     * Description: !!!!!!!!!!!!!!!!!!!!
     *
     *****************************************************************************************/
    public bool SetHexValue(string newHexValue)
    {
        /* TBD. */
    }

    /******************************************************************************************
     * 
     * Name: SetHighNibble   
     * 
     * Author(s): Michael Beaver
     *                 
     * Input: !!!!!!!!!!!!!!!!!!!!
     * Return: True/False
     * Description: !!!!!!!!!!!!!!!!!!!!
     *
     *****************************************************************************************/
    public bool SetHighNibble(Bit[] highSrc)
    {
        /* Retain the original value in case of an error. */
        Bit[] tempHigh = new Bit[NIBBLE_SIZE];
        tempHigh = high;

        for (int i = 0; i < NIBBLE_SIZE; i++)
        {
            if (!(high[i].SetValue(highSrc[i])))
            {
                /* Revert to the original value. */
                high = tempHigh;
                return false;
            }
        }

        return true;
    }

    /******************************************************************************************
     * 
     * Name: SetIntegerValue   
     * 
     * Author(s): Michael Beaver
     *                 
     * Input: !!!!!!!!!!!!!!!!!!!!
     * Return: True/False
     * Description: !!!!!!!!!!!!!!!!!!!!
     *
     *****************************************************************************************/
    public bool SetIntegerValue(int newValue)
    {
        /* TBD. */
    }

    /******************************************************************************************
     * 
     * Name: SetLocked   
     * 
     * Author(s): Michael Beaver
     *                 
     * Input: !!!!!!!!!!!!!!!!!!!!
     * Return: N/A
     * Description: !!!!!!!!!!!!!!!!!!!!
     *
     *****************************************************************************************/
    public void SetLocked (bool newLock)
    {
        locked = newLock;
    }

    /******************************************************************************************
     * 
     * Name: SetLowNibble   
     * 
     * Author(s): Michael Beaver
     *                 
     * Input: !!!!!!!!!!!!!!!!!!!!
     * Return: True/False
     * Description: !!!!!!!!!!!!!!!!!!!!
     *
     *****************************************************************************************/
    public bool SetLowNibble(Bit[] highSrc)
    {
        /* Retain the original value in case of an error. */
        Bit[] tempLow = new Bit[NIBBLE_SIZE];
        tempLow = low;

        for (int i = 0; i < NIBBLE_SIZE; i++)
        {
            if (!(low[i].SetValue(lowSrc[i])))
            {
                /* Revert to the original value. */
                low = tempLow;
                return false;
            }
        }

        return true;
    }
    

    /* Private methods. */

}
