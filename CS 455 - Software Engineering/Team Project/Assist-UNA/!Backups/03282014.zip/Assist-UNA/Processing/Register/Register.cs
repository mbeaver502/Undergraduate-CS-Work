﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Byte;

/**************************************************************************************************
* 
* Name: Register
* 
* ================================================================================================
* 
* Description: !!!!!!!!!!!!!!!!!!!!
*              
*                       
* ================================================================================================        
* 
* Modification History
* --------------------
* 03/25/2014    JMB  Class created.
*                      
*************************************************************************************************/

class Register
{

    /* Constants. */
    const int NUM_BYTES = 4;

    /* Private members. */
    AssistByte[] contents = new AssistByte[NUM_BYTES];
    int value;

    /* Public methods. */

    /******************************************************************************************
     * 
     * Name: GetBytes
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    public AssistByte[] GetBytes()
    {
        return contents;
    }

    /******************************************************************************************
     * 
     * Name: GetBytesString
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    public string GetBytesString()
    {
        return this.BytesToString();
    }

    /******************************************************************************************
     * 
     * Name: GetValue
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    public int GetValue()
    {
        return value;
    }

    /******************************************************************************************
     * 
     * Name: Register
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    public Register()
    {
        for (int i = 0; i < NUM_BYTES; i++)
            contents[i].SetHexValue("F4");
        
        /* Default F4F4F4F4 integer value. This needs to be a constant. */
        value = -185273100;
    }

    /******************************************************************************************
     * 
     * Name: SetContents
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    public bool SetContents(string hexValue)
    {
        int j = 1;

        /* Break string into byte pairs. */
        for (int i = 0; i < NUM_BYTES - 1; i + 2)
        {
            contents[i].SetHexValue(hexValue[i] + hexValue[j]);
            j++;
        }

        return true;
    }


    /* Private methods. */

    /******************************************************************************************
     * 
     * Name: BytesToString
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    private string BytesToString()
    {
        string result;

        for (int i = 0; i < NUM_BYTES; i++)
            result += contents[i].GetHexValue();

        return result;
    }

}
