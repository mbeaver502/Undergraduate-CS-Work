﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Byte;
using Register;
using Bit;

/**************************************************************************************************
* 
* Name: PSW
* 
* ================================================================================================
* 
* Description: !!!!!!!!!!!!!!!!!!!!
*              
*                       
* ================================================================================================        
* 
* Modification History
* --------------------
* 03/25/2014    JMB  Class created.
*                      
*************************************************************************************************/

class PSW : Register
{

    /* Constants. */
    const int NUM_BITS_CC = 2;
    const int NUM_BYTES_INST_ADDR = 3;
    const int NUM_BYTES = 8;

    /* Private members. */
    AssistByte[] contents = new AssistByte[NUM_BYTES];
    AssistByte[] instructionAddress = new AssistByte[NUM_BYTES_INST_ADDR];
    Bit[] conditionCode = new Bit[NUM_BITS_CC];


    /* Public methods. */

    /******************************************************************************************
     * 
     * Name: PSW
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    public PSW()
    {
        /* TBD. */
    }

    /******************************************************************************************
     * 
     * Name: GetConditionCode
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    public int GetConditionCode()
    {
        if (conditionCode[0] == 0)
        {
            if (conditionCode[1] == 0)
                return 0;

            else
                return 1;
        }

        else if (conditionCode[0] == 1)
        {
            if (conditionCode[1] == 0)
                return 2;

            else
                return 3;
        }
    }

    /******************************************************************************************
     * 
     * Name: GetConditionCode
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    public string GetConditionCode()
    {
        string result;

        result = Convert.ToString(conditionCode[0]) + Convert.ToString(conditionCode[1]);
        return result;
    }

    /******************************************************************************************
     * 
     * Name: GetInstructionAddress
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    public string GetInstructionAddress()
    {
        string result;

        for (int i = 0; i < NUM_BYTES_INST_ADDR; i++)
            result += instructionAddress[i].GetHexValue();

        return result;
    }

    /******************************************************************************************
     * 
     * Name: SetConditionCode
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    public bool SetConditionCode(int cc)
    {
        switch(cc)
        {
            case 0:
                {
                    conditionCode[0] = 0;
                    conditionCode[1] = 0;
                    break;
                }

            case 1:
                {
                    conditionCode[0] = 0;
                    conditionCode[1] = 1;
                    break;
                }

            case 2:
                {
                    conditionCode[0] = 1;
                    conditionCode[1] = 0;
                    break;
                }

            case 3:
                {
                    conditionCode[0] = 1;
                    conditionCode[1] = 1;
                    break;
                }

            default:
                /* Error. */
                break;
        }

        return true;
    }

    /******************************************************************************************
     * 
     * Name: SetInstructionAddress
     * 
     * Author(s): Michael Beaver
     *                     
     * Input: !!!!!!!!!!!!!!!!!!!!      
     * Return: !!!!!!!!!!!!!!!!!!!!      
     * Description: !!!!!!!!!!!!!!!!!!!! 
     *              
     *              
     *****************************************************************************************/
    public bool SetInstructionAddress(string hexValue)
    {
        /* TBD. */
    }

}
