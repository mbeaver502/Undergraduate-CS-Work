/*
	Names: Michael Beaver, Scott Smoke, and Wenhao Wang
	CS420, Fall 2013
	Assignment: CPU Scheduling Algorithms
	Description: This program runs simulations of the Shortest Job First, Priority, and Round Robin
		CPU scheduling algorithms. The number of ready queues simulated is user-specified, but the data
		in the Process Control Blocks (PCBs) is randomly generated. The user has the option to
		compare a specified number of Round Robin time slices against each other. A table of 
		statistical data is output after the simulations have completed.
    Due Date: December 3, 2013
*/

#include <iostream>
#include <stdio.h>
#include <ctime>
#include <vector>
#include <string>

#include "Schedule.h"
#include "PCB.h"

using namespace std;

//------------------------------------------------------------------------------------------------------

const unsigned int MAX_PROCS = 500;
const unsigned int PID_BOUND = 1000;
const unsigned int BURST_BOUND = 100;

const unsigned int MAX_QUEUES = 8;
const unsigned int MIN_QUEUES = 1;

const unsigned int MAX_RR = 3;
const unsigned int MIN_RR = 1;

const string LINE = "-------------------------------------------------------------------------------";

//------------------------------------------------------------------------------------------------------

void getInitVals(int & numQueues, int & numRR, int time[MAX_RR]);
void doSim(int numQueues, int numRR, int time[MAX_RR]);

void genRandom(vector<PCB> & readyVector);
bool search(vector<PCB> & temp, int pid);

//------------------------------------------------------------------------------------------------------

int main() {

	srand(time(NULL)); //initial seed

	int numQueues = 1;
	int numRR = 1;
	int time[MAX_RR] = {0};

	getInitVals(numQueues, numRR, time);
	system("CLS");
	doSim(numQueues, numRR, time);

	cout << endl;
	system("PAUSE");
	return 0;

}



/*
	Name: genRandom
	Authors: Scott Smoke
	Purpose: This will randomly generate the number of processes, the burst time, and pid.
		References: cplusplus.com
	Input:
	Output:
	Return:
*/
void genRandom(vector<PCB> & readyVector) {

	srand(rand());

	int r = 0;

	for (unsigned int i = 0; i < MAX_PROCS; i++) {

		srand(rand());	//reseed
		r = rand();

		// Only add PCBs with unique PIDs
		if(search(readyVector, (r % PID_BOUND) + 1) == false)
			readyVector.push_back(PCB((r % PID_BOUND) + 1, (r % BURST_BOUND) + 1));
	
	}

}



/*
	Name: search
	Authors: Scott Smoke
	Purpose:
	Input:
	Output:
	Return:
*/
bool search(vector<PCB> & temp, int pid) {

	int i = 0;
	int vecSize = temp.size();

	// Compare each PCB against the given PID
	for(int i = 0 ; i < vecSize; i++)
		if(pid == temp[i].getPID())
			return true;
	
	return false;

}



/*
	Name: getInitVals
	Authors: Michael Beaver
	Purpose: Prompts the user for initial simulation values.
	Input: numQueues is the number of queues to simulate, numRR is the number of
		Round Robin time slices to simulate, and time is an array of time slice values.
	Output: numQueues is the number of queues to simulate, numRR is the number of
		Round Robin time slices to simulate, and time is an array of time slice values.
	Return: N/A (void)
*/
void getInitVals(int & numQueues, int & numRR, int time[MAX_RR]) {

	// Getting number of queues
	cout << "Number of queues to simulate [" << MIN_QUEUES << ", " << MAX_QUEUES <<"]: ";
	cin >> numQueues;
	if (numQueues > MAX_QUEUES)
		numQueues = MAX_QUEUES;
	else if (numQueues < MIN_QUEUES)
		numQueues = MIN_QUEUES;

	// Getting number of time slices
	cout << "Number of Round Robin time slices to simulate [" << MIN_RR << ", " << MAX_RR <<"]: ";
	cin >> numRR;
	if (numRR > MAX_RR)
		numRR = MAX_RR;
	else if (numRR < MIN_RR)
		numRR = MIN_RR;

	// Getting the time slices
	cout << endl;
	for (int i = 0; i < numRR; i++) {

		cout << "Round Robin #" << i + 1 << " time slice: ";
		cin >> time[i];

	}
	cout << endl;

}



/*
	Name: doSim
	Authors: Michael Beaver and Scott Smoke
	Purpose: Runs the scheduler simulations and outputs a table of statistical results.
	Input: numQueues is the number of queues to simulate, numRR is the number of
		Round Robin time slices to simulate, and time is an array of time slice values.
	Output: N/A
	Return: N/A (void)
*/
void doSim(int numQueues, int numRR, int time[MAX_RR]) {

	// Dynamically allocated containers
	vector<PCB> * readyQueues = new vector<PCB>[numQueues];
	SJF * mySJF = new SJF[numQueues];
	Priority * myPriority = new Priority[numQueues];
	RoundRobin * myRR = new RoundRobin[numQueues];

	// Randomly generate the queues
	for (int i = 0; i < numQueues; i++)
		genRandom(readyQueues[i]);

	// Initialize and simulate the simpler schedulers
	for (int i = 0; i < numQueues; i++) {

		mySJF[i].setReadyQueue(readyQueues[i]);
		myPriority[i].setReadyQueue(readyQueues[i]);

		mySJF[i].runSchedule();
		myPriority[i].runSchedule();

	}

	// Output Shortest Job First Results
	cout << LINE << endl;
	cout << "     SJF    |  # Procs  |  Avg Burst  |  Avg Wait  |  Avg Resp  |   Avg Turn" << endl;
	cout << LINE << endl;
	for (int i = 0; i < numQueues; i++) {

		printf("  Q%d        |  %7d  |  %*.2f  |  %*.2f  |  %*.2f  |  %*.2f\n", 
				i + 1,
				myPriority[i].getNumProcs(), 
				9, myPriority[i].getAvgBurst(), 
				8, mySJF[i].getAvgWait(), 
				8, mySJF[i].getAvgResp(), 
				8, mySJF[i].getAvgTurn());

	}
	cout << LINE << endl;

	// Output Priority Results
	cout << "  Priority  |  # Procs  |  Avg Burst  |  Avg Wait  |  Avg Resp  |   Avg Turn" << endl;
	cout << LINE << endl;
	for (int i = 0; i < numQueues; i++) {

		printf("  Q%d        |  %7d  |  %*.2f  |  %*.2f  |  %*.2f  |  %*.2f\n", 
				i + 1,
				myPriority[i].getNumProcs(), 
				9, myPriority[i].getAvgBurst(), 
				8, myPriority[i].getAvgWait(), 
				8, myPriority[i].getAvgResp(), 
				8, myPriority[i].getAvgTurn());

	}
	cout << LINE << endl;

	// Simulate the Round Robin cases
	for (int j = 0; j < numRR; j++) {

		// Output Round Robin Results
		cout << "  RR |  TS  |  # Procs  |  Avg Burst  |  Avg Wait  |  Avg Resp  |   Avg Turn" << endl;
		cout << LINE << endl;
		for (int i = 0; i < numQueues; i++) {

			// Simulation happens here (to accomodate numerous time slice simulations)
			myRR[i].setReadyQueue(readyQueues[i]);
			myRR[i].setTimeSlice(time[j]);
			myRR[i].runSchedule();

			printf("  Q%d | %*d |  %7d  |  %*.2f  |  %*.2f  |  %*.2f  |  %*.2f\n",
					i + 1,
					4, myRR[i].getTimeSlice(),
					myRR[i].getNumProcs(), 
					9, myRR[i].getAvgBurst(), 
					8, myRR[i].getAvgWait(), 
					8, myRR[i].getAvgResp(), 
					8, myRR[i].getAvgTurn());

			// Data must be reset after each simulation
			myRR[i].resetData();

		}

		cout << LINE << endl;

	}

	// Returning memory
	for (int i = 0; i < numQueues; i++)
		readyQueues[i].clear();

	delete [] readyQueues;
	delete [] mySJF;
	delete [] myPriority;
	delete [] myRR;

}