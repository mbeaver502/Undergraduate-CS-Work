/*
	Names: Michael Beaver, Scott Smoke, and Wenhao Wang
	CS420, Fall 2013
	Assignment: CPU Scheduling Algorithms
	Description: This program runs simulations of the Shortest Job First, Priority, and Round Robin
		CPU scheduling algorithms. The number of ready queues simulated is user-specified, but the data
		in the Process Control Blocks (PCBs) is randomly generated. The user has the option to
		compare a specified number of Round Robin time slices against each other. A table of 
		statistical data is output after the simulations have completed.
    Due Date: December 3, 2013
*/

#ifndef PCB_H
#define PCB_H

/*
	Process States:
		-2 = Terminated
		-1 = Waiting
		 0 = Ready
		 1 = Running
*/
class PCB {

	private:
		int pid;			// process�ID,�may�be�randomly�generated�within�some�reasonable�range�
		int proState;		// state�of�the�process�(ready,�running,�waiting)�
		int cpuTime;		// CPU�Burst�time�(next�burst�time,�may�be�randomly�generated)�
		int arrTime;		// You�can�determine�Arrival�time�as�all�0; however,�allow�for�various�arrival�times�
		int waitTime;		// calculated�
		int respTime;		// calculated�
		int turnTime;		// calculated�
		int remBurst;		// Remaining burst time, for Round Robin
		int executionTime;  // mutatable variable of burst time

	public:
		int priority;		// Process priority

		PCB();
		PCB(int id, int cputBurst);
		PCB(int id, int cpuBurst, int state, int arrival, int procPriority);
		PCB(const PCB & right);

		int getProState() const;
		int getPID() const;
		int getArrTime() const;
		int getWaitTime() const;
		int getRespTime() const;
		int getTurnTime() const;
		int getBurstTime() const;
		int getRemBurst() const;
		int getPriority() const;
		int getExecution() const;

		void setPID(int newPID);
		void setCPUTime(int cpuBurst);
		void setArrTime(int arrival); 
		bool setProState(int state);
		void setWaitTime(int wait);
		void setRespTime(int resp);
		void setTurnTime(int turn);
		void setPriority(int nPriority);
		void setRemBurst(int burst);
		void setExecutionTime(int exec);

		PCB & operator =(const PCB & rhs);
		friend bool operator <(const PCB & lhs, const PCB & rhs);

};

#endif