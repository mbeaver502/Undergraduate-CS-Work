/*
	Michael Beaver, Scott Smoke, and Wenhao Wang
	CS 420, Fall 2013
	Programming Assignment #3
	November 18, 2013
	
	Description:
		This program will check a sudoku table for its validity. It will take a variable number
		of filename arguments; each file contains a sudoku table solution. It will then output whether
		the solution is valid or invalid as appropriate. It is assumed that the user will only input  
		values [1,9] in their tables, and the program will not process a table that fails to meet this 
		condition. If invalid, the program will give the row, column, or block/subgrid where the table 
		is invalid. Entries in the solution file are delimited by a space, and rows are marked by a 
		new line. See sample.txt for an example solution.

	Example uses:
		./<execName> sample.txt
		./<execName> sol5.txt sol3.txt sol1.txt sol4.txt
*/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

//-------------------------------------------------------------------------------------------

struct PARAMETERS {

	int row;
	int col;

	int block;

};

//-------------------------------------------------------------------------------------------

int sudokuTable[9][9];
bool colCheck[9];
bool rowCheck[9];
bool blockCheck[9];

//-------------------------------------------------------------------------------------------

bool readData(const char * fileName);
void outputTable();

bool goCols();
bool goRows();
bool goBlocks();

void * checkCols(void * param);
void * checkRows(void * param);
void * checkBlocks(void * param);

//-------------------------------------------------------------------------------------------

/*
	Name: main
	Authors: Michael Beaver, Scott Smoke, and Wenhao Wang
	Purpose: This is the driver function. It will check if a file or files contain
		valid sudoku solutions by calling the appropriate functions.
	Incoming: argc is the number of arguments, and argv contains the arguments from
		the terminal.
	Outgoing: N/A
	Return: Returns 0 on successful execution and -1 if unsuccessful.
*/
int main(int argc, char * argv[]) {

	if (argc < 2) {

		fprintf(stderr, "You must specify a file(s) containing your solution(s)!\n");
		return -1;

	}

	bool validSolution;

	// Analyze each of the proposed solutions
	for (int i = 1; i < argc; i++) {

		validSolution = true;

		// Attempt to read data from the solution file
		cout << endl << "FILE: " << argv[i] << endl << endl;
		if (!(readData(argv[i]))) {

			cout << "\tINVALID FILE: " << argv[i] << endl << endl;
			//return -1;
			continue;

		}

		outputTable();
		cout << endl;

		// Check columns
		if (!(goCols()))
			validSolution = false;

		// Check rows
		if (!(goRows()))
			validSolution = false;	

		// Check Blocks
		if (!(goBlocks()))
			validSolution = false;

		// Output validity of solution
		if (validSolution)
			cout << endl << "\t=> VALID SOLUTION" << endl << endl;
		else
			cout << endl << "\t=> INVALID SOLUTION" << endl << endl;

		// Pause for the user
		if ((argc - i) > 1) {

			cout << "Press ENTER to continue . . . ";
			cin.get();

		}

	}
	
	return 0;

}

//-------------------------------------------------------------------------------------------

/*
	Name: readData
	Authors: Michael Beaver, Scott Smoke, and Wenhao Wang
	Purpose: This function reads the sudoku solution data from the input
		file into the sudokuTable global array.
	Incoming: fileName is the name of the solution file.
	Outgoing: N/A
	Return: Returns true if data is read successfully and false if an
		error occurs.
*/
bool readData(const char * fileName) {

	ifstream myFile;
	int i = 0;
	int value;

	myFile.open(fileName);

	// Check to see if file exists
	if (!(myFile.is_open())) {

		cout << "\tINVALID FILE: FILE DOES NOT EXIST" << endl;
		myFile.close();
		
		return false;

	}

	// Read solution data into table array
	while(!myFile.eof()) {

		for (int j = 0; j < 9; j++) {

			myFile >> value;

			// Check value validity
			if ((value < 1) || (value > 9)) {

				cout << "\tILLEGAL VALUE: [" << i + 1 << ", " << j + 1 << "] = " << value << endl;
				return false;

			}

			sudokuTable[i][j] = value;

		}

		i++;

	}

	myFile.close();
	return true;
	
}

//-------------------------------------------------------------------------------------------

/*
	Name: outputTable
	Authors: Michael Beaver, Scott Smoke, and Wenhao Wang
	Purpose: This function displays the actual sudoku table.
	Incoming: N/A
	Outgoing: N/A
	Return: N/A (void)
*/
void outputTable() {

	for (int i = 0; i < 9; i++) {

		cout << "\t";

		for (int j = 0; j < 9; j++) 
			cout << sudokuTable[i][j] << " ";

		cout << endl;

	}

}

//-------------------------------------------------------------------------------------------

/*
	Name: goCols
	Authors: Michael Beaver, Scott Smoke, and Wenhao Wang
	Purpose: This function creates the threads necessary to check each
		column in the solution.
	Incoming: N/A
	Outgoing: N/A
	Return: Returns true if all columns are valid and false if at least one
		column is invalid.
*/
bool goCols() {

	pthread_t tid;
	pthread_attr_t attr;

	bool result = true;
	
	// Check columns
	for (int i = 0; i < 9; i++) {

		PARAMETERS myParams;
		myParams.row = 0;
		myParams.col = i;

		pthread_attr_init(&attr);
		pthread_create(&tid, &attr, checkCols, (void *)(&myParams));
		pthread_join(tid, NULL);

	}
	
	// Checking columns validity
	for (int i = 0; i < 9; i++) {

		if (colCheck[i] == false) {

			cout << "\tINVALID COLUMN: " << i + 1 << endl;
			result = false;

		}
		
	}

	return result;

}

//-------------------------------------------------------------------------------------------

/*
	Name: goRows
	Authors: Michael Beaver, Scott Smoke, and Wenhao Wang
	Purpose: This function creates the threads necessary to check each
		row in the solution.
	Incoming: N/A
	Outgoing: N/A
	Return: Returns true if all rows are valid and false if at least one
		row is invalid.
*/
bool goRows() {

	pthread_t tid;
	pthread_attr_t attr;
	
	bool result = true;

	// Check rows
	for (int i = 0; i < 9; i++) {

		PARAMETERS myParams;
		myParams.row = i;
		myParams.col = 0;

		pthread_attr_init(&attr);
		pthread_create(&tid, &attr, checkRows, (void *)(&myParams));
		pthread_join(tid, NULL);

	}

	// Check rows validity
	for (int i = 0; i < 9; i++) {

		if (rowCheck[i] == false) {

			cout << "\tINVALID ROW: " << i + 1 << endl;
			result = false;

		}
		
	}

	return result;

}

//-------------------------------------------------------------------------------------------

/*
	Name: goBlocks
	Authors: Michael Beaver, Scott Smoke, and Wenhao Wang
	Purpose: This function creates the threads necessary to check each
		3x3 block/subgrid in the solution.
	Incoming: N/A
	Outgoing: N/A
	Return: Returns true if all 3x3 blocks/subgrids are valid and false if 
		at least one 3x3 block/subgrid is invalid
*/
bool goBlocks() {

	pthread_t tidArr[9];
	pthread_attr_t attrArr[9];
	PARAMETERS blockArr[9];
	bool result = true;

	// Initialize 3x3 blocks
	for (int i = 0; i < 3; i++) {

		// Top row of 3x3 blocks
		blockArr[i].row = 0;
		blockArr[i].col = (i * 3);
		blockArr[i].block = (i + 1);

		// Middle row of 3x3 blocks
		blockArr[i + 3].row = 3;
		blockArr[i + 3].col = (i * 3);
		blockArr[i + 3].block = (i + 4);

		// Bottom row of 3x3 blocks
		blockArr[i + 6].row = 6;
		blockArr[i + 6].col = (i * 3);
		blockArr[i + 6].block = (i + 7);

	}

	// Threading happens here
	for (int i = 0; i < 9; i++) {

		// Get default thread attributes
		pthread_attr_init(&(attrArr[i]));

		// Create the threads
		pthread_create(&(tidArr[i]), &(attrArr[i]), checkBlocks, (void *)(&(blockArr[i])));

		// Wait for the threads to finish
		pthread_join(tidArr[i], NULL);

	}

	// Check blocks validity
	for (int i = 0; i < 9; i++) {

		if (blockCheck[i] == false) {

			cout << "\tINVALID BLOCK: " << i + 1 << endl;
			result = false;

		}
		
	}

	return result;

}

//-------------------------------------------------------------------------------------------

/*
	Name: checkCols
	Authors: Michael Beaver, Scott Smoke, and Wenhao Wang
	Purpose: This function will check if a given column contains exactly
		one copy of a value in the range [1,9]. If the column is valid,
		the global column validity array colCheck is updated to true
		for the appropriate column. Otherwise, the value is updated to
		false if the column is invalid.
	Incoming: param is a PARAMETERS struct that contains the row and column
		indices.
	Outgoing: N/A
	Return: N/A (void)
*/
void * checkCols(void * param) {

	PARAMETERS * myParams;
	myParams = (PARAMETERS *)param;
	
	int valMap[9] = {0};
	int temp;

	// Increment the appropriate array value for the value in the solution table
	for (int i = 0; i < 9; i++) {
		
		temp = sudokuTable[i][myParams->col];
		valMap[temp - 1]++;
		
	}

	// Valid solutions will have one and only one of each digit in each column
	for (int i = 0; i < 9; i++) {

		if (valMap[i] != 1) {

			colCheck[myParams->col] = false;
			break;

		}

		colCheck[myParams->col] = true;

	}

	pthread_exit(0);

}

//-------------------------------------------------------------------------------------------

/*
	Name: checkRows
	Authors: Michael Beaver, Scott Smoke, and Wenhao Wang
	Purpose: This function will check if a given row contains exactly
		one copy of a value in the range [1,9]. If the row is valid,
		the global row validity array rowCheck is updated to true
		for the appropriate row. Otherwise, the value is updated to
		false if the row is invalid.
	Incoming: param is a PARAMETERS struct that contains the row and column
		indices.
	Outgoing: N/A
	Return: N/A (void)
*/
void * checkRows(void * param) {

	PARAMETERS * myParams;
	myParams = (PARAMETERS *)param;
	
	int valMap[9] = {0};
	int temp;

	// Increment the appropriate array value for the value in the solution table
	for (int i = 0; i < 9; i++) {
		
		temp = sudokuTable[myParams->row][i];
		valMap[temp - 1]++;

	}

	// Valid solutions will have one and only one of each digit in each row
	for (int i = 0; i < 9; i++) {

		if (valMap[i] != 1) {

			rowCheck[myParams->row] = false;
			break;

		}

		rowCheck[myParams->row] = true;

	}

	pthread_exit(0);

}

//-------------------------------------------------------------------------------------------

/*
	Name: checkBlocks
	Authors: Michael Beaver, Scott Smoke, and Wenhao Wang
	Purpose: This function will check if a given block contains exactly
		one copy of a value in the range [1,9]. If the block is valid,
		the global block validity array blockChek is updated to true
		for the appropriate block. Otherwise, the value is updated to
		false if the block is invalid.
	Incoming: param is a PARAMETERS struct that contains the row, column, and
		block indices.
	Outgoing: N/A
	Return: N/A (void)
*/
void * checkBlocks(void * param) {

	PARAMETERS * myParams;
	myParams = (PARAMETERS *)param;
	
	int valMap[9] = {0};
	int row = myParams->row;
	int col = myParams->col;
	int block = myParams->block - 1;
	int temp;

	// Increment the appropriate array value for the value in the solution table
	for (int i = row; i < row + 3; i++) {

		for (int j = col; j < col + 3; j++) {

			temp = sudokuTable[i][j];
			valMap[temp - 1]++;

		}

	}

	// Valid solutions will have one and only one of each digit in each 3x3 block
	for (int i = 0; i < 9; i++) {

		if (valMap[i] != 1) {

			blockCheck[block] = false;
			break;

		}

		blockCheck[block] = true;

	}

	pthread_exit(0);

}

