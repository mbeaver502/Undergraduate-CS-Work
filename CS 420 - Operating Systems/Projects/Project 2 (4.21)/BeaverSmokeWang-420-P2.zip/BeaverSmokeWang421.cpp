/*
	Michael Beaver, Scott Smoke, and Wenhao Wang
	CS 420, Fall 2013
	Programming Assignment #2
	November 11, 2013
	
	This program uses pthreads to calculate the average, minimum value, and maximum
	value of a user-specified list of integers. The user specifies the list of integers
	at execution as arguments for the program. The statistical values are reported by the 
	main function after all threads have completed execution.

	Compile options: g++ -o <execName> BeaverSmokeWang421.cpp -pthread
	Example use: ./<execName> 90 81 78 95 79 72 85
*/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

//------------------------------------------------------------------------------------------

float avg;				
int min;
int max;

//------------------------------------------------------------------------------------------

void * doAverage(void * param);	
void * findMin(void * param);	
void * findMax(void * param);	

//------------------------------------------------------------------------------------------

// THREAD_DATA struct and code usage adapted from:
// Blaise Barney, https://computing.llnl.gov/tutorials/pthreads/#PassingArguments
struct THREAD_DATA {

	int numVals;
	char ** argv;

};

//------------------------------------------------------------------------------------------

/*
	Name: main
	Authors: Michael Beaver, Scott Smoke, and Wenhao Wang
	Purpose: Driver that takes in integer data and creates the appropriate threads for
		 data processing. The statistical results are reported here.
	Incoming: argc is the number of arguments for the program, and argv is the list
		 of arguments.
	Outgoing: N/A
	Return: Returns 0 if successful and -1 if unsuccessful
*/
int main(int argc, char * argv[]) {

	pthread_t tid1, tid2, tid3;		// Thread identifiers
	pthread_attr_t attr1, attr2, attr3;	// Sets of thread attributes

	if (argc < 2) {

		fprintf(stderr, "You must specify a list of integers!\n");
		return -1;

	}

	// Prepare data for threads
	THREAD_DATA myData;
	myData.numVals = argc - 1;
	myData.argv = argv;
	
	// Get the default thread attributes
	pthread_attr_init(&attr1);					
	pthread_attr_init(&attr2);
	pthread_attr_init(&attr3);

	// Create the threads
	pthread_create(&tid1, &attr1, doAverage, (void *)(&myData));
	pthread_create(&tid2, &attr2, findMin,   (void *)(&myData));
	pthread_create(&tid3, &attr3, findMax,   (void *)(&myData));

	// Wait for the threads to finish
	pthread_join(tid1, NULL);
	pthread_join(tid2, NULL);
	pthread_join(tid3, NULL);					

	// Report statistical findings
	printf("\nThe average value is %f\n", avg);
	printf("The minimum value is %d\n",   min);
	printf("The maximum value is %d\n\n", max);
	
	return 0;

}

//------------------------------------------------------------------------------------------

/*
	Name: doAverage
	Authors: Michael Beaver, Scott Smoke, and Wenhao Wang
	Purpose: The average of a list of numbers is calculated and stored in the global
		 variable avg.
	Incoming: param is a pointer to the struct object holding the relevant data.
	Outgoing: The global variable avg will be updated to contain the average of 
		 the list of numbers.
	Return: N/A (void)
*/
void * doAverage(void * param) {

	int numVals;
	char ** argv;

	// Making a new, temporary set of data for this thread
	THREAD_DATA * myData;
	myData = (THREAD_DATA *)param;
	
	// Copy values into new struct from old struct
	numVals = myData->numVals;
	argv = myData->argv;
	avg = 0;

	// Calculate the average
	for (int i = 1; i <= numVals; i++)
		avg += atoi(argv[i]);
	avg /= numVals;

	pthread_exit(0);

}

//------------------------------------------------------------------------------------------

/*
	Name: findMin
	Authors: Michael Beaver, Scott Smoke, and Wenhao Wang
	Purpose: The minimum value in the list of integers is found and stored in the
		 global variable min.
	Incoming: param is a pointer to a struct object with the relevant data.
	Outgoing: The global variable min is updated to contain the minimum value in the list.
	Return: N/A (void)
*/
void * findMin(void * param) {

	int numVals, tempMin;
	char ** argv;

	// Making a new, temporary set of data for this thread
	THREAD_DATA * myData;
	myData = (THREAD_DATA *)param;
	
	// Copy values into new struct from old struct
	numVals = myData->numVals;
	argv = myData->argv;

	// Determine minimum value
	tempMin = atoi(argv[1]);
	for (int i = 2; i <= numVals; i++)
		if (atoi(argv[i]) < tempMin)
			tempMin = atoi(argv[i]);
	min = tempMin;

	pthread_exit(0);

}

//------------------------------------------------------------------------------------------

/*
	Name: findMax
	Authors: Michael Beaver, Scott Smoke, and Wenhao Wang
	Purpose: The maximum value in the list of integers is found and stored in the
		 global variable max.
	Incoming: param is a pointer to a struct object with the relevant data.
	Outgoing: The global variable max is updated to contain the maximum value in the list.
	Return: N/A (void)
*/
void * findMax(void * param) {

	int numVals, tempMax;
	char ** argv;

	// Making a new, temporary set of data for this thread
	THREAD_DATA * myData;
	myData = (THREAD_DATA *)param;
	
	// Copy values into new struct from old struct
	numVals = myData->numVals;
	argv = myData->argv;

	// Determine maximum value
	tempMax = atoi(argv[1]);
	for (int i = 2; i <= numVals; i++) 
		if (atoi(argv[i]) > tempMax)
			tempMax = atoi(argv[i]);
	max = tempMax;

	pthread_exit(0);

}


